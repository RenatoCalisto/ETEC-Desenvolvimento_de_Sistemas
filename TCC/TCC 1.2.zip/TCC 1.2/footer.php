
<footer class="bg-primary text-white">
        <div class="container">
          <div class="row py-4">
            <div class="col-12 col-md text-center mx-auto">
              
              <h3>Atomo</h3>
              <h4>Cursos Técnicos</h4> 
              <p class="text-white-50 text-small">
                Mais de 150 tipos de cursos técnicos gratuitos<br> 
                Presente em 156 municípios brasileiros, como o total de 212 polos Atomos no país. <br>
                208 mil estudantes <br>    
                Desde 1911<br>
 
              </p>
            </div>
            <div class="col-12 col-md text-center mx-auto">
              <h3> Links</h3>
              <ul>
                <a href="sobre.php" class="text-white">Quem somos nós</a><br>
              </ul>
            </div>
            <div class="col-12 col-md text-center mx-auto">
              <h3> <section id="sociais"> </h3>
              <ul>
<img src="img/Atomologo.png" width="150" alt="Logo da Escola">
                <br>
                <div class="copyright text-center text-lg-left">
                  &copy; Copyright. All rights reserved.
              </ul></section>
            </div>
          </div>
        </div>
      </footer>

